/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>
#include "message.h"

#define TOUR	(int)6773 		// [tck/tr/roue] = 500*distance entre roue(=264mm)/diamètre roue(=70mm)

void main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	UART_XBee_Start();
	UART_Asser_Start();
	UART_Asser_RX_isr_Start();

    CYGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
	
	CyDelay(1000);
	sendRED();
	
	sendXY_COURBE((long)0xFFFF*1400/3000, (long)0xFFFF*400/3000, (long)0xFFFF*5/3000);
	sendALPHA(0, 10);//*/
	
	/*sendXY_RAPIDE((long)0xFFFF*400/3000, (long)0xFFFF*575/3000, (long)0xFFFF*5/3000);
	sendALPHA(0, 10);
	while(!hasAsserDone) CyDelay(10); hasAsserDone = FALSE;
	sendXY_COURBE((long)0xFFFF*575/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*750/3000, (long)0xFFFF*225/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*925/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1100/3000, (long)0xFFFF*575/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1275/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1450/3000, (long)0xFFFF*225/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1625/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1800/3000, (long)0xFFFF*575/3000, (long)0xFFFF*2/300);
	sendXY_RAPIDE((long)0xFFFF*2150/3000, (long)0xFFFF*400/3000, (long)0xFFFF*1/3000);
	sendALPHA(0, 10);
	while(!hasAsserDone) CyDelay(10); hasAsserDone = FALSE;
	sendXY_RAPIDE((long)0xFFFF*1800/3000, (long)0xFFFF*575/3000, (long)0xFFFF*5/3000);
	sendALPHA(0, 10);
	while(!hasAsserDone) CyDelay(10); hasAsserDone = FALSE;
	sendXY_COURBE((long)0xFFFF*1625/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1450/3000, (long)0xFFFF*225/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1275/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*1100/3000, (long)0xFFFF*575/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*925/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*750/3000, (long)0xFFFF*225/3000, (long)0xFFFF*2/300);
	sendXY_COURBE((long)0xFFFF*575/3000, (long)0xFFFF*400/3000, (long)0xFFFF*2/300);
	sendXY_RAPIDE((long)0xFFFF*400/3000, (long)0xFFFF*575/3000, (long)0xFFFF*5/3000);
	sendALPHA(0, 10);//*/
	
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
